CREATE TABLE IF NOT EXISTS `sample___` (
    `id` TINYINT,
    `column` VARCHAR(50),
    `column` VARCHAR(50),
    `column` VARCHAR(50),
    `column` VARCHAR(50),
    `column` VARCHAR(50)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sample___` (`id`, `column`, `column`, `column`, `column`, `column`) VALUES
(1, 'True', 'True', 'True', 'True', 'True'),
(2, 'True', 'True', 'True', 'True', 'True'),
(3, 'False', 'False', 'False', 'False', 'False'),
(4, 'True', 'True', 'True', 'True', 'True'),
(5, 'True', 'True', 'True', 'True', 'True');

CREATE TABLE IF NOT EXISTS `sample___` (
    `id` TINYINT,
    `column` VARCHAR(50),
    `column` VARCHAR(50),
    `column` VARCHAR(50),
    `column` VARCHAR(50)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sample___` (`id`, `column`, `column`, `column`, `column`) VALUES
(1, '1000000', '1000000', '1000000', '1000000'),
(2, '800000', '800000', '800000', '800000'),
(3, '500000', '500000', '500000', '500000'),
(4, '300000', '300000', '300000', '300000');