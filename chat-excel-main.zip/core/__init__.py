"""
Chat-Excel核心模块

包含Excel解析和SQL生成的核心功能
"""